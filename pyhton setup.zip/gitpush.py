import subprocess

def push_changes(commit_message):
	subprocess.run(["git", "add", "."], check=True)
	subprocess.run(["git", "commit", "-m", commit_message], check=True)
	subprocess.run(["git", "push", "origin", "HEAD"], check=True)


def main():
	commit_message = input("\033[36mEnter your commit message: \033[0m").strip()
	if not commit_message:
		raise SystemExit("\033[93mCommit message cannot be empty.\033[0m")

	push_changes(commit_message)
	print("\033[1;92mChanges pushed to GitHub.\033[0m")


if __name__ == "__main__":
	main()
